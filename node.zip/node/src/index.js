import express from 'express';
import vogels from 'vogels';
import Joi from 'joi';
import bodyParser from 'body-parser';
import microtime from 'microtime';
import AWS from 'aws-sdk';
import crypto from 'crypto';

const app = express();

// app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use( bodyParser.json() );       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
}));

vogels.AWS.config.update({accessKeyId: 'AKIAIYBDNQZGNYONATIA', secretAccessKey: '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', region: "us-west-2"});

AWS.config.update({accessKeyId: 'AKIAIYBDNQZGNYONATIA', secretAccessKey: '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', region: "us-west-2"});
var ses = new AWS.SES({apiVersion: '2010-12-01'});

const Account = vogels.define('account', {
  hashKey : 'email',
  schema : {
    id: Joi.string(),
    email: Joi.string(),
    password : Joi.string(),
    familyName: Joi.string(),
    familyDescribe: Joi.string(),
    familyFavoritePlace: Joi.string(),
    userToken: Joi.string()
  }
});

const ADD= vogels.define('add', {
  hashKey : 'id',
  schema : {
    id: Joi.string(),
    email: Joi.string(),
    description: Joi.string(),
    think: Joi.string(),
    erfs: Joi.string()
  }
});

const FamilyMember = vogels.define('familymember', {
  hashKey : 'id',
  schema : {
    id: Joi.string(),
    accountHashKey: Joi.string(),
    nickname: Joi.string(),
    gk: Joi.string(),
    likeColor : Joi.string(),
    favoriteSaying: Joi.string(),
    erfs: Joi.string()
  }
});

var str = "";
app.post('/signup/account', function(req, res) {

  var createID = "" + microtime.now();
  var createEMAIL = "";
  var createPASSWORD = "";
  var createFAMILYNAME = "";
  var createFAMILYDESCRIBE = "";
  var createFAMILYFAVORITEPLACE = "";
  if (req.body["email"]) {
    createEMAIL = req.body["email"];
  } else {
    createEMAIL = req.body["?email"];
  }
  if (req.body["password"]) {
    createPASSWORD = req.body["password"];
  } else {
    createPASSWORD = req.body["?password"];
  }
  if (req.body["familyName"]) {
    createFAMILYNAME = req.body["familyName"];
  } else {
    createFAMILYNAME = req.body["?familyName"];
  }
  if (req.body["familyDescribe"]) {
    createFAMILYDESCRIBE = req.body["familyDescribe"];
  } else {
    createFAMILYDESCRIBE = req.body["?familyDescribe"];
  }
  if (req.body["familyFavoritePlace"]) {
    createFAMILYFAVORITEPLACE = req.body["familyFavoritePlace"];
  } else {
    createFAMILYFAVORITEPLACE = req.body["?familyFavoritePlace"];
  }

  Account
    .scan()
    .where('email').equals(createEMAIL.toLowerCase())
    .exec(function(err, acc){
      if (acc["Count"] == 0) {
        const userToken = crypto.createHash('sha256').update(createEMAIL.toLowerCase()).digest('hex');

        Account.create({ id: createID, email: createEMAIL.toLowerCase(), password: createPASSWORD, familyName: createFAMILYNAME,
          familyDescribe: createFAMILYDESCRIBE, familyFavoritePlace: createFAMILYFAVORITEPLACE, userToken:userToken}, (err, acc) => {
          res.json({res: createID});
        });
      } else {
        res.json({res: "THIS EMAIL IS ALREADY EXIST."});
      }
    });



});

app.post('/signup/familymember', function(req, res) {
  var createID = "" + microtime.now();
  var createAccountHashKey = "";
  var createNickName = "";
  var createGK = "";
  var createLikeColor = "";
  var createFavoriteSaying = "";
  var createERFS = "";
  if (req.body["accountHashKey"]) {
    createAccountHashKey = req.body["accountHashKey"];
  } else {
    createAccountHashKey = req.body["?accountHashKey"];
  }
  if (req.body["nickname"]) {
    createNickName = req.body["nickname"];
  } else {
    createNickName = req.body["?nickname"];
  }
  if (req.body["gk"]) {
    createGK = req.body["gk"];
  } else {
    createGK = req.body["?gk"];
  }
  if (req.body["likeColor"]) {
    createLikeColor = req.body["likeColor"];
  } else {
    createLikeColor = req.body["?likeColor"];
  }
  if (req.body["erfs"]) {
    createERFS = req.body["erfs"];
  } else {
    createERFS = req.body["?erfs"];
  }
  if (req.body["favoriteSaying"]) {
    createFavoriteSaying = req.body["favoriteSaying"];
  } else {
    createFavoriteSaying = req.body["?favoriteSaying"];
  }

  FamilyMember.create({ id: createID, accountHashKey: createAccountHashKey, nickname: createNickName, gk: createGK, likeColor: createLikeColor,
    favoriteSaying: createFavoriteSaying, erfs: createERFS}, (err, acc) => {
      res.json({res: createAccountHashKey});
  });

});

app.post('/signin/family', function(req, res) {
  var requestedHashKey = "";
  if (req.body["email"]) {
    requestedHashKey = req.body["email"];
  } else {
    requestedHashKey = req.body["?email"];
  }
  Account.get(requestedHashKey.toLowerCase(), function (err, acc) {
    if (acc == null) {
      res.json({password: "There is no email you entered"});
    } else {
      res.json({password: acc.get('password'), accountHashKey: acc.get('id')});
    }
  });
});

app.post('/memberdetails', function(req, res) {
  // console.log(req.body);
  // res.json({res: req.body});
  var requestedMemberID = "";
  if (req.body["memberID"]) {
    requestedMemberID = req.body["memberID"];
  } else {
    requestedMemberID= req.body["?memberID"];
  }


});

app.post('/sendforgotmail', function(req, res) {

  console.log(req.body);

  var requestedEmail = "";
  if (req.body["email"]) {
    requestedEmail = req.body["email"];
  } else {
    requestedEmail = req.body["?email"];
  }

  var to = [requestedEmail.toLowerCase()];

  const userToken = crypto.createHash('sha256').update(requestedEmail.toLowerCase()).digest('hex');


  var from = 'lucas.leon.777@gmail.com';
  ses.sendEmail(
    {
      Source: from,
      Destination: { ToAddresses: to },
      Message: {
        Subject: {
          Data: 'Forgot Password'
        },
        Body: {
          Text: {
            Data: 'Please click here link to reset your password. http://172.20.2.173:3000/resetpassword/' + userToken
          }
        }
      }
    }
    , function(err, data) {
      if(err) throw err;
      console.log('Email sent:');
      console.log(data);
    });

  console.log(req.body["email"]);
 res.json({res: "Sent Request Successfully"});
});


app.post('/signin/allmembers', function(req, res) {
  var requestedHashKey = "";
  if (req.body["accountHashKey"]) {
    requestedHashKey = req.body["accountHashKey"];
  } else {
    requestedHashKey = req.body["?accountHashKey"];
  }

  FamilyMember
    .scan()
    .where('accountHashKey').equals(requestedHashKey)
    .exec(function(err, acc){
      res.json({acc: acc});
    });
});

app.get('/resetpassword/:emailToken', function (req, res, next) {
  // console.log(req.body);
  console.log(req.params);
  var requestEmail = req.params["emailToken"];

  const userToken = crypto.createHash('sha256').update(requestEmail.toLowerCase()).digest('hex');

  res.render('index', {title: 'Forgot your password?', requestEmail: ''});
});

app.post('/resetpassword/result', function(req,res){

  console.log(req.body);

  var email = req.body["email"];
  var password = req.body["password"];
  var confirmpassword = req.body["confirmpassword"];

  const userToken = crypto.createHash('sha256').update(email.toLowerCase()).digest('hex');

  Account
    .scan()
    .where('userToken').equals(userToken)
    .exec(function(err, acc){
      if (acc["Count"] == 0) {
        res.render('done', {title: 'There is no email you entered. Please check your email and retry.'});
      } else {
        if (password == confirmpassword) {
          Account.update({email: email.toLowerCase(), password: password}, function (err, acc) {
            console.log('update account', acc.get('password'));
          });
          res.render('done', {title: 'Your password reseted successfully.'});
        } else {
          res.render('done', {title: 'Password is not matched. Please Try again.'});
        }
      }
    });



});

app.post('/testrequest', function (req, res) {
  Account.update({email: 'A@a.com', password: 'u'}, function (err, acc) {
    console.log('update account', acc.get('password'));
  });
  res.json({res: ""});
});


app.listen(3000);

console.log('server has been started');
