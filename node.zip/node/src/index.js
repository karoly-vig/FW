import express from 'express';
import vogels from 'vogels';
import Joi from 'joi';
import path from 'path';
import bodyParser from 'body-parser';
import microtime from 'microtime';
import AWS from 'aws-sdk';
import crypto from 'crypto';

const app = express();

///notification

////// iOS
var apn = require('apn');

let apnProvider = new apn.Provider({
  cert      : path.join(__dirname, '../keys/apns-dis-cert.pem'),
  key       : path.join(__dirname, '../keys/apns-dis-key.pem'),
  production: true
});

app.post('/sendNotification', function (req, res) {
// Set up apn with the APNs Auth Keyvar note = new apn.Notification();

  var note = new apn.Notification();

  note.expiry  = Math.floor(Date.now() / 1000) + 3600; // Expires 1 hour from now.
  note.sound   = "ping.aiff";
  note.badge   = 1;
  note.alert   = {'title':'I love you', "body":'I hate you'};
  note.payload = {'age': '1', "name":'pyi', "addr": 'py', "phonenumber":'-', "familymember":'-', "special_data" : {"no": "1", "profile":"wwww", "email":"ilya@gmail.com"}};

  apnProvider.send(note, '367366bd6018f6e32ccf04c5be6bb2d5338050e01f968346cc0ece990e679d06').then(function (result, err) {
    console.info('sendPushNotification result', result);
    console.info('sendPushNotification error', err);
    res.json({res: "notification sent."});
  });
});


////// android

var FCM = require('fcm-node');

var serverKey = 'AAAAJTMOzLU:APA91bF_mlZkKl-Pl6as5BjoMYzvAiZF8rMw9UWLzBHqb3CH9hZSH6UwlaKhTvoNsHMRcbruZmzGXN0vUwG78ZYqsztAtTkVQRxsQgEtK72bn2bXaw99wGtRYd0YIu73O1-PAN4SdHA7';
var fcm = new FCM(serverKey);

app.post('/sendAndroidNotification', function (req, res) {
// Set up apn with the APNs Auth Keyvar note = new apn.Notification();
  var message = { //this may vary according to the message type (single recipient, multicast, topic, et cetera)
    to: 'dF_vZ_r_4VA:APA91bF8UhVpQ-GqIh_kDhqv9O5sM2FULczvbrEtukk2tRvB5mSJXuCc-9hGoZCEKBsLJPyjRK7oII9bF35JxDlqmGBt5SDsuh_7FwQlrmMmmx_L5n9iiAiScpj8lbFmdzpQlC-z23O9',
    collapse_key: 'demo',

    notification: {
      title: 'Title of your push notification',
      body: 'Body of your push notification'
    },

    data: {  //you can send only notification or only data(or include both)
      // my_key: 'my value',
      // my_another_key: 'my another value'
      age: 1,
      name: "jch",
      addr: "pyongyang",
      phonenumber: "1912627282",
      familymember: 4,
      special_data: {
        email: 'ilya@gmail.com',
        no: 1
      }
    }
  };

  fcm.send(message, function(err, response){
    if (err) {
      console.log("Something has gone wrong!");
      res.json({res: "Notification Sent wrongly"});
    } else {
      console.log("Successfully sent with response: ", response);
      res.json({res: "Notification Sent successfully"});
    }
  });
});

///



// app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use( bodyParser.json() );       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
}));

vogels.AWS.config.update({accessKeyId: 'AKIAIYBDNQZGNYONATIA', secretAccessKey: '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', region: "us-east-1"});
AWS.config.update({accessKeyId: 'AKIAIYBDNQZGNYONATIA', secretAccessKey: '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', region: "us-east-1"});

var ses = new AWS.SES({apiVersion: '2010-12-01'});

const Account = vogels.define('ableusaccount', {
  hashKey : 'email',
  schema : {
    id: Joi.string(),
    email: Joi.string(),
    password : Joi.string(),
    familyName: Joi.string(),
    familyDescribe: Joi.string(),
    familyFavoritePlace: Joi.string(),
    userToken: Joi.string(),
    time: Joi.string()
  }
});

const Sender = vogels.define('ableussender', {
  hashKey : 'id',
  schema : {
    id: Joi.string(),
    email: Joi.string()
  }
});

const SignedDevice = vogels.define('ableussignedtoken', {
  hashKey : 'id',
  schema : {
    id: Joi.string(),
    signedMember: Joi.string(),
    signState: Joi.string(),
    device: Joi.string()
  }
});

const RandomSchedule = vogels.define('ableusrandomschedule', {
  hashKey : 'id',
  schema : {
    id: Joi.string(),
    state: Joi.string()
  }
});

const DefaultRandomMessage = vogels.define('ableusrandommessage', {
  hashKey : 'id',
  schema : {
    id: Joi.string(),
    message: Joi.string(),
    provenance: Joi.string(),
    erfs: Joi.string()
  }
});

const ADD= vogels.define('ableusadd', {
  hashKey : 'id',
  schema : {
    id: Joi.string(),
    description: Joi.string(),
    think: Joi.string(),
    erfs: Joi.string(),
    fromMemberID: Joi.string(),
    toMemberID: Joi.string(),
    date: Joi.string(),
    time: Joi.string(),
    songUrl: Joi.string(),
    accountKey: Joi.string()
  }
});

const LIFT = vogels.define('ableuslift', {
  hashKey : 'id',
  schema : {
    id: Joi.string(),
    erfs: Joi.string(),
    fromMemberID: Joi.string(),
    toMemberID: Joi.string(),
    date: Joi.string(),
    randomMessage: Joi.string(),
    time: Joi.string(),
    defaultLIFT: Joi.string()
  }
});

const FamilyMember = vogels.define('ableusfamilymember', {
  hashKey : 'id',
  schema : {
    id: Joi.string(),
    accountHashKey: Joi.string(),
    nickname: Joi.string(),
    gk: Joi.string(),
    likeColor : Joi.string(),
    favoriteSaying: Joi.string(),
    erfs: Joi.string(),
    time: Joi.string()
  }
});

const MyNotification = vogels.define('mynotification', {
  hashKey : 'id',
  schema : {
    id: Joi.string(),
    fromid: Joi.string(),
    toid: Joi.string(),
    time: Joi.string()
  }
});

var str = "";
app.post('/signup/account', function(req, res) {

  const uuidV4 = require('uuid/v4');

  var createID = uuidV4();//"" + microtime.now();
  var createEMAIL = "";
  var createPASSWORD = "";
  var createFAMILYNAME = "";
  var createFAMILYDESCRIBE = "";
  var createFAMILYFAVORITEPLACE = "";

  createEMAIL = req.body["email"];
  createPASSWORD = req.body["password"];
  createFAMILYNAME = req.body["familyName"];
  createFAMILYDESCRIBE = req.body["familyDescribe"];
  createFAMILYFAVORITEPLACE = req.body["familyFavoritePlace"];

  Account
    .scan()
    .where('email').equals(createEMAIL.toLowerCase())
    .exec(function(err, acc){
      if (acc == null) {
        console.log("No Data.");
        const userToken = crypto.createHash('sha256').update(createEMAIL.toLowerCase()).digest('hex');

        Account.create({ id: createID, email: createEMAIL.toLowerCase(), password: createPASSWORD, familyName: createFAMILYNAME,
          familyDescribe: createFAMILYDESCRIBE, familyFavoritePlace: createFAMILYFAVORITEPLACE, userToken:userToken, time: "" + microtime.now()}, (err, acc) => {
          res.json({res: createID});
        });
      } else {
        if (acc["Count"] == 0) {
          const userToken = crypto.createHash('sha256').update(createEMAIL.toLowerCase()).digest('hex');

          Account.create({ id: createID, email: createEMAIL.toLowerCase(), password: createPASSWORD, familyName: createFAMILYNAME,
            familyDescribe: createFAMILYDESCRIBE, familyFavoritePlace: createFAMILYFAVORITEPLACE, userToken:userToken, time: "" + microtime.now()}, (err, acc) => {
            res.json({res: createID});
          });
        } else {
          res.json({res: "THIS EMAIL IS ALREADY EXIST."});
        }
      }
    });
});

app.post('/signup/familymember', function(req, res) {

  const uuidV4 = require('uuid/v4');
  var createID = uuidV4();//"" + microtime.now();
  var createAccountHashKey = "";
  var createNickName = "";
  var createGK = "";
  var createLikeColor = "";
  var createFavoriteSaying = "";
  var createERFS = "";

  createAccountHashKey = req.body["accountHashKey"];
  createNickName = req.body["nickname"];
  createGK = req.body["gk"];
  createLikeColor = req.body["likeColor"];
  createERFS = req.body["erfs"];
  createFavoriteSaying = req.body["favoriteSaying"];

  var datetime = new Date();
  var monthArray = [];
  monthArray[0] = "Jan";
  monthArray[1] = "Feb";
  monthArray[2] = "Mar";
  monthArray[3] = "Apr";
  monthArray[4] = "May";
  monthArray[5] = "Jun";
  monthArray[6] = "Jul";
  monthArray[7] = "Aug";
  monthArray[8] = "Sep";
  monthArray[9] = "Oct";
  monthArray[10] = "Nov";
  monthArray[11] = "Dec";

  // var dateStr = datetime.getHours() + ":" + datetime.getMonth() + " " + datetime.getDate() + " " + monthArray[datetime.getMonth()] + " " + datetime.getFullYear();
  var dateStr = datetime.getDate() + " " + monthArray[datetime.getMonth()] + " " + datetime.getFullYear();

  ADD.create({ description: createFavoriteSaying, think: "1", fromMemberID: createID, toMemberID: createID, erfs: createERFS, id: uuidV4(), date: dateStr, time: "" + microtime.now(), songUrl: "...", accountKey: createAccountHashKey}, (err, acc) => {
    console.log('Default Add Created... Now go on...');
    console.log(createFavoriteSaying);
    console.log(createID);
  });
  FamilyMember.create({ id: createID, accountHashKey: createAccountHashKey, nickname: createNickName, gk: createGK, likeColor: createLikeColor,
    favoriteSaying: createFavoriteSaying, erfs: createERFS, time: "" + microtime.now()}, (err, acc) => {
    console.log('Go oned...');
    res.json({res: createID});
  });

});

app.post('/signin/family', function(req, res) {
  var requestedHashKey = "";
  requestedHashKey = req.body["email"];

  Account.get(requestedHashKey.toLowerCase(), function (err, acc) {
    if (acc == null) {
      res.json({password: "There is no email you entered"});
    } else {
      res.json({password: acc.get('password'), accountHashKey: acc.get('id')});
    }
  });
});

app.post('/memberdetails', function(req, res) {
  var requestedMemberID = "";
  requestedMemberID = req.body["memberID"];
});

app.post('/send/forgotmail', function(req, res) {

  console.log(req.body);

  var requestedEmail = "";
  requestedEmail = req.body["email"];

  var to = [requestedEmail.toLowerCase()];

  const userToken = crypto.createHash('sha256').update(requestedEmail.toLowerCase()).digest('hex');



  Sender.get("SenderEmail", function (err, acc) {
    if (acc == null) {
      res.json({res: "Load Data Fail"});
    } else {
      var from = acc.get("email");
      ses.sendEmail(
        {
          Source: from,
          Destination: { ToAddresses: to },
          Message: {
            Subject: {
              Data: 'Forgot Password'
            },
            Body: {
              Text: {
                Data: 'Please click here ' + 'http://35.166.157.227:3000/resetpassword/' + userToken + ' to reset your password.'//'Please click here link to reset your password. http://172.20.2.173:3000/resetpassword/' + userToken
              }
            }
          }
        }
        , function(err, data) {
          if(err) throw err;
          console.log('Email sent:');
          console.log(data);
        });

      console.log(req.body["email"]);
      res.json({res: "Sent Request Successfully"});
    }
  });
});

app.post('/signup/welcome', function(req, res) {
  console.log(req.body);

  var requestedEmail = "";
  var requestedFamilyName = "";

  requestedEmail = req.body["email"];
  requestedFamilyName = req.body["familyName"];

  var to = [requestedEmail.toLowerCase()];

  var re = /(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))/;

  if(re.test(to)) {

    Sender.get("SenderEmail", function (err, acc) {
      if (acc == null) {
        res.json({res: "Load Data Fail"});
      } else {
        var from = acc.get("email");

        ses.sendEmail(
          {
            Source: from,
            Destination: { ToAddresses: to },
            Message: {
              Subject: {
                Data: 'Welcome'
              },
              Body: {
                Text: {
                  Data: "Welcome " + requestedFamilyName + " family, We are really excited that you are trying the Able Us app. This email address is your user name. We'd appreciate any feedback you might have so please reply and let us know. Thanks, Aparna."
                }
              }
            }
          }
          , function(err, data) {
            if(err) {
              res.json({res: "An Error Occured"});
            }
            console.log('Email sent:');
            console.log(data);
          });
          console.log(req.body["email"]);
          res.json({res: "Sent Request Successfully"});
        }
      });
    } else {
    console.log("error occured");
    res.json({res: "An Error Occured"});
  }
});


app.post('/signin/allmembers', function(req, res) {
  var requestedHashKey = "";
  requestedHashKey = req.body["accountHashKey"];

  FamilyMember
    .scan()
    .where('accountHashKey').equals(requestedHashKey)
    .exec(function(err, acc){
      console.log(acc);
      res.json({acc: acc});
    });
});

app.post('/member/info', function (req, res) {
  var requestedHashKey = "";
  requestedHashKey = req.body["memberHashKey"];

  FamilyMember
    .scan()
    .where('id').equals(requestedHashKey)
    .exec(function(err, acc){
      res.json({acc: acc});
    });
});

app.post('/member/update', function (req, res) {
  var requestedHashKey = "";
  var requestedNickName = "";
  var requestedGK = "";
  var requestedColor = "";
  var requestedFS = "";
  var requestedERFS = "";

  requestedHashKey = req.body["memberHashKey"];
  requestedNickName = req.body["nickName"];
  requestedGK = req.body["gk"];
  requestedColor = req.body["color"];
  requestedFS = req.body["favoriteSaying"];
  requestedERFS = req.body["erfs"];
  console.log("~~~~~~~~~~~~~~~~~~~~~~~~");
  console.log(requestedHashKey);
  console.log(requestedNickName);
  console.log(requestedGK);
  console.log(requestedColor);
  console.log(requestedFS);
  console.log(requestedERFS);
  console.log("~~~~~~~~~~~~~~~~~~~~~~~~");
  FamilyMember.update({id: requestedHashKey, erfs: requestedERFS, favoriteSaying: requestedFS, gk: requestedGK, likeColor: requestedColor, nickname: requestedNickName}, function (err, acc) {
    console.log('update member', acc.get('nickname'));
    res.json({res: "updated successfully"});
  });

});

global.isValidEmail = "";

app.get('/resetpassword/:emailToken', function (req, res, next) {
  // console.log(req.body);

  console.log("this is the result1");

  console.log(req.params);
  var requestEmailToken = req.params["emailToken"];
  ///
  global.isValidEmail = requestEmailToken;
  ///

  res.render('index', {title: 'Forgot your password?', requestEmail: ''});

});

app.post('/resetpassword/result', function(req,res){

  console.log("this is the result2");
  console.log(req.body);

  var email = req.body["email"];
  var password = req.body["password"];
  var confirmpassword = req.body["confirmpassword"];

  const userToken = crypto.createHash('sha256').update(email.toLowerCase()).digest('hex');

  ///
  if (global.isValidEmail == userToken) {
    Account
      .scan()
      .where('userToken').equals(userToken)
      .exec(function(err, acc){
        if (acc["Count"] == 0) {
          res.render('done', {title: 'There is no email you entered. Please check your email and retry.'});
        } else {
          if (password == confirmpassword) {
            Account.update({email: email.toLowerCase(), password: password}, function (err, acc) {
              console.log('update account', acc.get('password'));
            });
            res.render('done', {title: 'Your password reseted successfully.'});
          } else {
            res.render('done', {title: 'Password is not matched. Please Try again.'});
          }
        }
      });
  } else {
    console.log("invalid mail");
    res.render('done', {title: "Sorry, You didn't input your correct email address. Please check again and retry."});
  }
  ///
});

app.post('/add/publish', function (req, res) {
  var requestFromMemberID = "";
  var requestToMemberID = "";
  var requestAddDesc = "";
  var requestAddThink = "";
  var requestAddErfs = "";
  var requestSongUrl = "";
  var requestAccountHashKey = "";

  requestFromMemberID = req.body["fromMemberID"];
  requestToMemberID = req.body["toMemberID"];
  requestAddDesc = req.body["addDesc"];
  requestAddErfs = req.body["addERFS"];
  requestAddThink = req.body["addThink"];
  requestSongUrl = req.body["songUrl"];
  requestAccountHashKey = req.body["accountHashKey"];
  if (requestSongUrl == "") {
    requestSongUrl = "...";
  }
  var datetime = new Date();
  var monthArray = [];
  monthArray[0] = "Jan";
  monthArray[1] = "Feb";
  monthArray[2] = "Mar";
  monthArray[3] = "Apr";
  monthArray[4] = "May";
  monthArray[5] = "Jun";
  monthArray[6] = "Jul";
  monthArray[7] = "Aug";
  monthArray[8] = "Sep";
  monthArray[9] = "Oct";
  monthArray[10] = "Nov";
  monthArray[11] = "Dec";

  // var dateStr = datetime.getHours() + ":" + datetime.getMonth() + " " + datetime.getDate() + " " + monthArray[datetime.getMonth()] + " " + datetime.getFullYear();
  var dateStr = datetime.getDate() + " " + monthArray[datetime.getMonth()] + " " + datetime.getFullYear();
  const uuidV4 = require('uuid/v4');
  console.log("OK");

  ADD.create({ description: requestAddDesc, think: requestAddThink, fromMemberID: requestFromMemberID, toMemberID: requestToMemberID, erfs: requestAddErfs, id: uuidV4(), date: dateStr, time: "" + microtime.now(), songUrl: requestSongUrl, accountKey: requestAccountHashKey}, (err, acc) => {
    console.log("updated = " + requestAddDesc + " " + requestAddThink + " " + requestFromMemberID + " " + requestToMemberID + " " + requestAddErfs);
    res.json({res: req.body });
  });
});

app.post('/add/retrieve', function(req, res) {
  var requestMemberID = "";
  requestMemberID = req.body["fromMemberID"];
  console.log("request member id = " + requestMemberID);
  ADD
    .scan()
    .where('toMemberID').equals(requestMemberID)
    .exec(function(err, acc){
      console.log(acc);
      res.json({acc: acc});
    });
});

app.post('/lift/retrieve', function(req, res) {
  console.log("received request");
  var requestToMemberID = "";
  requestToMemberID = req.body["toMemberID"];

  LIFT
    .scan()
    .where('toMemberID').equals(requestToMemberID)
    .exec(function(err, acc){
      console.log("sent response");
      res.json({acc: acc});
    });
});


app.post('/add/remove', function(req, res) {
  var requestMemberID = "";
  requestMemberID = req.body["hash"];

  console.log(requestMemberID);
  ADD.destroy(requestMemberID, function (err) {
    res.json({res: 'removed'});
  });
});

app.post('/lift/remove', function(req, res) {
  var requestMemberID = "";
  requestMemberID = req.body["hash"];

  console.log(requestMemberID);
  LIFT.destroy(requestMemberID, function (err) {
    res.json({res: 'removed'});
  });
});


app.post('/lift/publish', function (req, res) {
  var requestFromMemberID = "";
  var requestToMemberID = "";
  var requestLiftErfs = "";
  var requestRandomMessage = "";

  requestFromMemberID = req.body["frommemberID"];
  requestToMemberID= req.body["tomemberID"];
  requestLiftErfs = req.body["liftERFS"];
  requestRandomMessage = req.body["randomMessage"];

  console.log(requestFromMemberID);
  console.log(requestToMemberID);
  console.log(requestLiftErfs);
  console.log(requestRandomMessage);



  var datetime = new Date();
  var monthArray = [];
  monthArray[0] = "Jan";
  monthArray[1] = "Feb";
  monthArray[2] = "Mar";
  monthArray[3] = "Apr";
  monthArray[4] = "May";
  monthArray[5] = "Jun";
  monthArray[6] = "Jul";
  monthArray[7] = "Aug";
  monthArray[8] = "Sep";
  monthArray[9] = "Oct";
  monthArray[10] = "Nov";
  monthArray[11] = "Dec";
  var dateStr = datetime.getDate() + " " + monthArray[datetime.getMonth()] + " " + datetime.getFullYear();

  const uuidV4 = require('uuid/v4');

  ADD
    .scan()
    .where('toMemberID').equals(requestToMemberID)
    .where('erfs').equals(requestLiftErfs)
    .exec(function(err, acc){
      if (acc["Count"] == 0) {
        console.log("No Data");

        DefaultRandomMessage
        .scan()
        .where('erfs').equals(requestLiftErfs)
        .exec(function (err, acc) {
          if (acc["Count"] == 0) {
            console.log("Really No Data.");
            res.json({res: "No Data To Send"});
          } else {
            var randomMessageCount = 0;
            randomMessageCount = Math.floor(Math.random() * acc["Count"]);

            //send iOS Notification
            SignedDevice
              .scan()
              .where('signedMember').equals(requestToMemberID)
              .where('signState').equals('true')
              .where('device').equals('ios')
              .exec(function (err, acc) {
                if (acc["Count"] == 0) {

                } else {

                  for (var i = 0; i < acc["Count"]; i++) {
                    var note = new apn.Notification();

                    note.expiry  = Math.floor(Date.now() / 1000) + 3600; // Expires 1 hour from now.
                    note.sound   = "ping.aiff";
                    note.badge   = 1;
                    note.alert   = {'title':'New Notification', "body":'Someone sent you one lift.'};
                    // note.payload = {'age': '1', "name":'pyi', "addr": 'py', "phonenumber":'-', "familymember":'-', "special_data" : {"no": "1", "profile":"wwww", "email":"ilya@gmail.com"}};

                    apnProvider.send(note, acc["Items"][i].get("id")).then(function (result, err) {});

                  }

                }
              });

            //send android Notification
            SignedDevice
              .scan()
              .where('signedMember').equals(requestToMemberID)
              .where('signState').equals('true')
              .where('device').equals('android')
              .exec(function (err, acc) {
                if (acc["Count"] == 0) {

                } else {
                  for (var i = 0; i < acc["Count"]; i++) {
                    var message = { //this may vary according to the message type (single recipient, multicast, topic, et cetera)
                      to: acc["Items"][i].get("id"),
                      collapse_key: 'demo',

                      notification: {
                        title: 'New Notification',
                        body: 'Someone Sent you one lift'
                      },

                      data: {  //you can send only notification or only data(or include both)
                        // age: 1,
                        // name: "jch",
                        // addr: "pyongyang",
                        // phonenumber: "1912627282",
                        // familymember: 4,
                        // special_data: {
                        //   email: 'ilya@gmail.com',
                        //   no: 1
                        // }
                      }
                    };

                    fcm.send(message, function(err, response){
                      if (err) {
                        console.log("Something has gone wrong!");
                      } else {
                        console.log("Successfully sent with response: ", response);
                      }
                    });

                  }

                }
              });

            LIFT.create({ erfs: acc["Items"][randomMessageCount].get("erfs"), fromMemberID: acc["Items"][randomMessageCount].get("provenance"), toMemberID: requestToMemberID, id: uuidV4(), date: dateStr, randomMessage: acc["Items"][randomMessageCount].get("message"), time: "" + microtime.now(), defaultLIFT:"true"}, (err, acc) => {
              res.json({res: "Published Success"});
            });

          }
        });
      } else {
        console.log("Retrieve Success.");
        var randomIndex = 0;
        randomIndex = Math.floor(Math.random() * acc["Count"]);
        console.log("Random = " + randomIndex);

        //send iOS Notification
        SignedDevice
          .scan()
          .where('signedMember').equals(requestToMemberID)
          .where('signState').equals('true')
          .where('device').equals('ios')
          .exec(function (err, acc) {
            if (acc["Count"] == 0) {

            } else {

              for (var i = 0; i < acc["Count"]; i++) {
                var note = new apn.Notification();

                note.expiry  = Math.floor(Date.now() / 1000) + 3600; // Expires 1 hour from now.
                note.sound   = "ping.aiff";
                note.badge   = 1;
                note.alert   = {'title':'New Notification', "body":'Someone sent you one lift.'};
                // note.payload = {'age': '1', "name":'pyi', "addr": 'py', "phonenumber":'-', "familymember":'-', "special_data" : {"no": "1", "profile":"wwww", "email":"ilya@gmail.com"}};

                apnProvider.send(note, acc["Items"][i].get("id")).then(function (result, err) {});

              }

            }
          });

        //send android Notification
        SignedDevice
          .scan()
          .where('signedMember').equals(requestToMemberID)
          .where('signState').equals('true')
          .where('device').equals('android')
          .exec(function (err, acc) {
            if (acc["Count"] == 0) {

            } else {
              for (var i = 0; i < acc["Count"]; i++) {
                var message = { //this may vary according to the message type (single recipient, multicast, topic, et cetera)
                  to: acc["Items"][i].get("id"),
                  collapse_key: 'demo',

                  notification: {
                    title: 'New Notification',
                    body: 'Someone Sent you one lift'
                  },

                  data: {  //you can send only notification or only data(or include both)
                    // age: 1,
                    // name: "jch",
                    // addr: "pyongyang",
                    // phonenumber: "1912627282",
                    // familymember: 4,
                    // special_data: {
                    //   email: 'ilya@gmail.com',
                    //   no: 1
                    // }
                  }
                };

                fcm.send(message, function(err, response){
                  if (err) {
                    console.log("Something has gone wrong!");
                  } else {
                    console.log("Successfully sent with response: ", response);
                  }
                });

              }

            }
          });


        LIFT.create({ erfs: acc["Items"][randomIndex].get("erfs"), fromMemberID: acc["Items"][randomIndex].get("fromMemberID"), toMemberID: acc["Items"][randomIndex].get("toMemberID"), id: uuidV4(), date: dateStr, randomMessage: acc["Items"][randomIndex].get("description"), time: "" + microtime.now(), defaultLIFT:"false"}, (err, acc) => {
          res.json({res: "Published Success"});
        });
      }
    });


});

app.post('/setSignState', function (req, res) {
  var requestToken = req.body["token"];
  var requestMember = req.body["memberID"];
  var requestState = req.body["signState"];
  var requestDevice = req.body["device"];

  console.log("entered");

  SignedDevice.get(requestToken, function (err, acc) {
    if (acc == null) {

      console.log(requestToken);
      SignedDevice.create({id: requestToken, signedMember: requestMember, signState: requestState, device: requestDevice}, function (err, acc) {
        res.json({res: "Updated Successfully"});
      });
      console.log("1");
    } else {
      SignedDevice.update({id: requestToken, signedMember: requestMember, signState: requestState, device: requestDevice}, function (err, acc) {
        res.json({res: "Updated Successfully"});
      });
      console.log("2");
    }
  });
});

app.post('/setRandomNotification', function (req, res) {
  var requestState = req.body["state"];
  var requestMember = req.body["signedMember"];
  console.log(requestMember);
  console.log(requestState);

  const uuidV4 = require('uuid/v4');


  RandomSchedule
    .scan()
    .where("signedMember").equals(requestMember)
    .exec(function (err, acc) {
      if (acc == null) {
        console.log("acc is null");
        RandomSchedule.create({id: requestMember, state: requestState}, function (err, acc) {
          res.json({res: "Created Successfully"});
        });
      } else {
        console.log("acc is not null");
        if (acc["Count"] == 0) {
          console.log("acc is 0");
          RandomSchedule.create({id: requestMember, state: requestState}, function (err, acc) {
            res.json({res: "Created Successfully"});
          });
        } else {
          console.log("acc is not 0");
          RandomSchedule.update({id: requestMember, state: requestState}, function (err, acc) {
            res.json({res: "Updated Successfully"});
          });

        }

      }
    });

});

app.post('/testrequest', function (req, res) {

  resetSchedule();
  res.json({res: Math.floor(Math.random() * 3)});
});

app.listen(3000);

console.log('server has been started');

function resetSchedule() {
  var datetime = new Date();
  if (datetime.getDay() == 0 && datetime.getHours() == 0) {
    runSchedule();
  } else {
    setTimeout(resetSchedule, 1000 * 3600);
  }
}

function runSchedule() {
  var schedule = require('node-schedule');
  var rule1 = new schedule.RecurrenceRule();
  rule1.second = Math.floor(Math.random() * 60);
  rule1.minute = Math.floor(Math.random() * 60);
  rule1.hour = Math.floor(Math.random() * 5) + 6;
  rule1.dayOfWeek = Math.floor(Math.random() * 7);

  var rule2 = new schedule.RecurrenceRule();
  rule2.second = Math.floor(Math.random() * 60);
  rule2.minute = Math.floor(Math.random() * 60);
  rule2.hour = Math.floor(Math.random() * 5) + 6;
  rule2.dayOfWeek = Math.floor(Math.random() * 7);

  var rule3 = new schedule.RecurrenceRule();
  rule3.second = Math.floor(Math.random() * 60);
  rule3.minute = Math.floor(Math.random() * 60);
  rule3.hour = Math.floor(Math.random() * 4) + 13;
  rule3.dayOfWeek = Math.floor(Math.random() * 7);

  var rule4 = new schedule.RecurrenceRule();
  rule4.second = Math.floor(Math.random() * 60);
  rule4.minute = Math.floor(Math.random() * 60);
  rule4.hour = Math.floor(Math.random() * 4) + 18;
  rule4.dayOfWeek = Math.floor(Math.random() * 7);

  var j1 = schedule.scheduleJob(rule, function(){
    console.log('The answer to life, the universe, and everything!');

    RandomSchedule
      .scan()
      .where('state').equals('on')
      .exec(function (err, acc) {
        if (acc == null) {
          res.json({res: "No Data"});
        } else {
          if (acc["Count"] == 0) {
            res.json({res: "No Data"});
          } else {
            var count = 0;
            count = acc["Count"];
            for (var i = 0; i < count; i++) {
              var toMemberID = acc["Items"][count].get("id");
              FamilyMember
                .scan()
                .where("id").equals(toMemberID)
                .exec(function (err, acc) {
                  var toAccountHashKey = acc["Items"][0].get("accountHashKey");
                  var toID = toMemberID;
                  ADD
                    .scan()
                    .where("accountKey").equals(toAccountHashKey)
                    .exec(function (err, acc) {
                      if (acc == null) {

                      } else {
                        if (acc["Count"] == 0) {

                        } else {
                          var id = Math.floor(Math.random() * acc["Count"]);

                          var fromMemberID = acc["Items"][id].get("fromMemberID");
                          var erfs = acc["Items"][id].get("erfs");
                          var think = acc["Items"][id].get("think");
                          var description = acc["Items"][id].get("description");

                          ///////////////////////////////////////////////////////////////// Send Point
                          //send iOS Notification
                          SignedDevice
                            .scan()
                            .where('signedMember').equals(toID)
                            .where('signState').equals('true')
                            .where('device').equals('ios')
                            .exec(function (err, acc) {
                              if (acc["Count"] == 0) {

                              } else {

                                for (var i = 0; i < acc["Count"]; i++) {
                                  var note = new apn.Notification();

                                  note.expiry  = Math.floor(Date.now() / 1000) + 3600; // Expires 1 hour from now.
                                  note.sound   = "ping.aiff";
                                  note.badge   = 1;
                                  note.alert   = {'title':'New Notification', "body":'Someone sent you one lift.'};
                                  // note.payload = {'age': '1', "name":'pyi', "addr": 'py', "phonenumber":'-', "familymember":'-', "special_data" : {"no": "1", "profile":"wwww", "email":"ilya@gmail.com"}};

                                  apnProvider.send(note, acc["Items"][i].get("id")).then(function (result, err) {});

                                }

                              }
                            });

                          //send android Notification
                          SignedDevice
                            .scan()
                            .where('signedMember').equals(toID)
                            .where('signState').equals('true')
                            .where('device').equals('android')
                            .exec(function (err, acc) {
                              if (acc["Count"] == 0) {

                              } else {
                                for (var i = 0; i < acc["Count"]; i++) {
                                  var message = { //this may vary according to the message type (single recipient, multicast, topic, et cetera)
                                    to: acc["Items"][i].get("id"),
                                    collapse_key: 'demo',

                                    notification: {
                                      title: 'New Notification',
                                      body: 'Someone Sent you one lift'
                                    },

                                    data: {  //you can send only notification or only data(or include both)
                                    }
                                  };

                                  fcm.send(message, function(err, response){
                                    if (err) {
                                      console.log("Something has gone wrong!");
                                    } else {
                                      console.log("Successfully sent with response: ", response);
                                    }
                                  });

                                }

                              }
                            });
                          var datetime = new Date();
                          var monthArray = [];
                          monthArray[0] = "Jan";
                          monthArray[1] = "Feb";
                          monthArray[2] = "Mar";
                          monthArray[3] = "Apr";
                          monthArray[4] = "May";
                          monthArray[5] = "Jun";
                          monthArray[6] = "Jul";
                          monthArray[7] = "Aug";
                          monthArray[8] = "Sep";
                          monthArray[9] = "Oct";
                          monthArray[10] = "Nov";
                          monthArray[11] = "Dec";

                          // var dateStr = datetime.getHours() + ":" + datetime.getMonth() + " " + datetime.getDate() + " " + monthArray[datetime.getMonth()] + " " + datetime.getFullYear();
                          var dateStr = datetime.getDate() + " " + monthArray[datetime.getMonth()] + " " + datetime.getFullYear();

                          const uuidV4 = require('uuid/v4');

                          LIFT.create({ erfs: erfs, fromMemberID: fromMemberID, toMemberID: toID, id: uuidV4(), date: dateStr, randomMessage: description, time: "" + microtime.now(), defaultLIFT:"false"}, (err, acc) => {
                            res.json({res: "Published Success"});
                          });

                          /////////////////////////////////////////////////////////////////

                        }
                      }
                    });



                });

            }
          }
        }
      });

    j1.cancel();
  });
  var j2 = schedule.scheduleJob(rule, function(){
    console.log('The answer to life, the universe, and everything!');
    j2.cancel();
  });
  var j3 = schedule.scheduleJob(rule, function(){
    console.log('The answer to life, the universe, and everything!');
    j3.cancel();
  });
  var j4 = schedule.scheduleJob(rule, function(){
    console.log('The answer to life, the universe, and everything!');
    j4.cancel();
  });
}
